# Audit verification evidence

Companion evidence for CLAUDE-NEXT-STEPS.md and AUDIT-EVIDENCE.md. This is a reproduction kit, not another implementation plan.

Audited source: local Claude commit 969d501e5d318f8ff650d7e239d8647f8b75eb84. GitHub main at inspection was older, 7dfd3f2392510effc6f5d51e9708d502ff80bdbf. Use an isolated checkout with its normal installed dependencies. The audit used Node module mocking; use a Node version supporting the repository's test command. Never use this kit to restart a live replay or mutate its database.

The execution probes create temporary SQLite databases, run repository migrations there, insert artificial fixtures, and remove the temporary database on success. The model microchecks read/extract source expressions and execute artificial inputs. They do not call providers or use real bets. Scripts take the isolated repository's absolute path as their sole argument:

```sh
node execution-repro.mjs /absolute/path/to/isolated-repository
node --experimental-test-module-mocks execution-findings-repro.mjs /absolute/path/to/isolated-repository
node model-microchecks.mjs /absolute/path/to/isolated-repository
```

The expected outputs are retained in the correspondingly named result files. Outputs reproduce defects, so successful script execution does not mean the application passed those invariants. After fixes, replace these audit probes with real regression tests of the corrected behaviors. Source extraction is specific to the audited implementation and may require updating after refactors. The saved model output used the key impossibleReception; the portable script calls that same observation unlinkedOrdinaryReceivingTouchdown. A lateral recipient can legitimately receive touchdown credit with zero receptions. The defect is the sampler's absent play/lateral relationship, not the statistical combination in every possible NFL play.

execution-existing-tests.log retains the existing targeted 81-test pass. Those tests passed before the independent probes exposed defects; both facts belong in the evidence record.

audit-evidence.json is a frozen export from selected saved audit records, including run 27 and the 51-week run-31 prefix. numerical-review-values.json contains the independently recomputed market totals, opening-line diagnostics, outcomes, and uncertainty results. The live database is not included. Reproducing score joins and opening-line calculations requires a consistent read-only snapshot of the original game_lines data and the documented formulas; the full original conversation and private credentials are not part of this bundle.

These results are historical diagnostics and source-level behavior observations. They do not establish available historical prices, personal bankroll performance, or a profitable strategy. Refer to AUDIT-EVIDENCE.md for the distinctions and exact findings.

## Current strategy scope

The active implementation is now ordinary full-game pregame NFL spreads only. The original all-market export and prop probes remain historical audit evidence, not active feature work. spreads-only-evidence.json and .md add the relevant 153-selection baseline, per-season/weekly full-precision returns and 50,000-replicate weekly-bootstrap method. The spread-only ROI interval is approximately −23.22% to +7.51%; do not use the 545-selection pooled count or pooled uncertainty as spread-specific evidence. The T−60 operating protocol in the main plan is new and is not retroactively validated by these closing-history rows.
