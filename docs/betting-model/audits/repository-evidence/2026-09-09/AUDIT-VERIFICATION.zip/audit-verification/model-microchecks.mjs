import fs from 'node:fs';
import vm from 'node:vm';
const root = process.argv[2];
if (!root || !root.startsWith('/')) throw new Error('Pass the absolute path of an isolated audited repository as the first argument.');
const out = {};
const preseason = fs.readFileSync(`${root}/server/services/nfl-preseason-blend.js`, 'utf8');
const actualExpression = preseason.match(/const weightOnPrior = ([^;]+);/)[1];
const actualWeight = new Function('priorVariance', 'gamesPlayed', 'PER_GAME_VARIANCE', `return ${actualExpression}`);
out.preseason = [1,4,8].map(n => ({ games: n, implementation: actualWeight(36.5,n,181.5), precisionDerived:181.5/(181.5+n*36.5) }));
out.churn = { original: actualWeight(36.5,1,181.5), doubledPriorUncertainty:actualWeight(73,1,181.5) };
const props = fs.readFileSync(`${root}/server/services/nfl-props.js`, 'utf8');
const boardCode = props.slice(props.indexOf('  // Pair Over/Under quotes'), props.indexOf('  // Model-only view'));
const runBoard = (market,p) => {
 const ctx = {market,byName:new Map([['fixture player',{team:'AAA',position:'WR',_sims:{receptions:p,any_td:p}}]]),
  normalizeName:x=>x.toLowerCase(), MARKET_STAT:{player_receptions:'receptions',player_anytime_td:'any_td'},MARKET_LABEL:{},
  pOver:(a,l)=>a.filter(x=>x>l).length/a.length,calibrateAnytimeTd:x=>x,
  americanToProb:o=>o>0?100/(o+100):Math.abs(o)/(Math.abs(o)+100),r3:x=>x,mean:a=>a.reduce((s,x)=>s+x,0)/a.length,
  noVig:(a,b)=> a==null||b==null?null:0.5};
 return vm.runInNewContext(boardCode+'\nboard',ctx);
};
out.crossBook = runBoard([
 {event_id:'E1',market:'player_receptions',player:'Fixture Player',line:4.5,book:'A',side:'Over',american_price:-110},
 {event_id:'E1',market:'player_receptions',player:'Fixture Player',line:4.5,book:'B',side:'Under',american_price:-120},
 {event_id:'E1',market:'player_receptions',player:'Fixture Player',line:4.5,book:'B',side:'Over',american_price:130}
],[5,5,5,3]);
out.anytime = runBoard([{event_id:'E1',market:'player_anytime_td',player:'Fixture Player',line:null,book:'A',side:'Yes',american_price:150}],[0,0,0,1]);
const sampler = fs.readFileSync(`${root}/server/services/projections.js`,'utf8');
const samplerCode = sampler.slice(sampler.indexOf('export function sampleAllocatedWeekEvents'),sampler.indexOf('/** One simulated week scored')).replace('export ', '');
const samplerContext={randGamma:()=>0,randBinomial:(n,p)=> n===1?(p<0.5?1:0):0};
out.unlinkedOrdinaryReceivingTouchdown = vm.runInNewContext(samplerCode+'\nsampleAllocatedWeekEvents({catch_rate:0.7,rec_td_rate:0.1,pass_td_rate:0,int_rate:0,rush_td_rate:0,ypt:8,ypc:4,ypa:7},{targets:1})',samplerContext);
console.log(JSON.stringify(out,null,2));
