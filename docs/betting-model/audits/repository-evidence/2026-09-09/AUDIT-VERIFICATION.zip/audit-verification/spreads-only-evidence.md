# Frozen run-27 spread-only evidence

**The relevant sample for the spread-only scope is 153 bets: 72 wins, 78 losses and 3 pushes.** Stored net return is **-11.854884287563 units**, or **-7.7483% ROI** on 153 units risked. The win rate is **48.00%**, calculated from 150 non-push results. The previous 545-bet pooled sample combines markets and must not be used as the spread strategy's evidence size or win rate.

| Season | Audit weeks | Bets | Wins | Losses | Pushes | Net units | ROI | Win rate excluding pushes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2021 | 14 | 37 | 16 | 20 | 1 | -5.282409 | -14.28% | 44.44% |
| 2022 | 14 | 31 | 17 | 14 | 0 | +1.366523 | +4.41% | 54.84% |
| 2023 | 14 | 22 | 11 | 9 | 2 | +1.220827 | +5.55% | 55.00% |
| 2024 | 14 | 36 | 14 | 22 | 0 | -8.894037 | -24.71% | 38.89% |
| 2025 | 14 | 27 | 14 | 13 | 0 | -0.265788 | -0.98% | 51.85% |
| All | 70 | 153 | 72 | 78 | 3 | -11.854884 | -7.75% | 48.00% |

## Week-cluster uncertainty

A 50,000-replicate week-cluster bootstrap, seed `9021026`, gives an approximate 95% percentile interval for spread ROI of **[-23.22%, +7.51%]**. All **70** selected audit weeks are in the resampling population, including **6 weeks with no spread bets**. Each replicate draws 70 weeks with replacement, keeps each week's stake and return together, then divides the combined net return by combined stake. It does not average weekly ROI or resample individual bets independently. There were 0 zero-stake replicates.

The interval includes zero and is wide. The observed sample lost money, but this calculation does not establish a statistically proven negative long-run edge or a profitable edge. It preserves same-week grouping while assuming weeks are exchangeable independent clusters; dependence across weeks/seasons and model selection are additional limitations. It cannot correct historical-data timing defects or establish availability of executable quotes. Stored-unit reconstruction includes only the economics already encoded in those units.

## Exact source and method

Read only `audit-evidence.json`, SHA-256 `52f3bd6470a4ddabda4566044631b432afaf1ebb751ea2b057e956be88d9e5ff`. Selected `runs[].id == 27` (status `complete`), then `weeks[].run_id == 27`. Verified 70 unique ordinals `0..69`, exactly weeks 5–18 in each season 2021–2025. Selected each week's `picks[]` where `market == "spread"`. Counted `result` values `Won`, `Lost`, and `Push`; summed the full-precision stored `units` values, rather than rounded weekly `metrics.units`. Each included pick is one risked unit. Pushes return zero net units but remain in the ROI denominator. Win rate excludes pushes. No price or outcome was fetched or regraded.

The bootstrap uses Python 3.14.3's standard-library `random.Random(9021026)` and calls `rng.randrange(70)` 70 times per replicate against the ordinal-sorted weekly list. After sorting the 50,000 ROI values, reported endpoints use indexes `floor((N-1)*0.025)` and `floor((N-1)*0.975)`. This exact RNG and percentile definition are included because the seed alone does not uniquely specify a resampling implementation.

The companion `spreads-only-evidence.json` preserves full-precision aggregate and per-season values, every weekly count/return, source identity, method and limitations. No model fitting, replay, live-database access or runtime changes were performed.
