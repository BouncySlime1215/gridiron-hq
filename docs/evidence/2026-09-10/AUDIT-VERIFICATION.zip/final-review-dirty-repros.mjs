import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const root='/Users/nick_matta/Documents/Codex/2026-09-09/so-based-on-whats-in-this/work/claude-final-review-20260910';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gridiron-final-review-'));
process.env.GRIDIRON_DB_PATH=path.join(temp,'fixture.sqlite');process.env.SCHEDULER_DISABLED='1';
const {db,run}=await import(`${root}/server/db/index.js`);
await(await import(`${root}/server/db/migrate.js`)).runMigrations();
const out={};
const family=await import(`${root}/server/services/nfl-family-contribution.js`);
out.catalog=family.familyConsumers().map(x=>({family:x.family,models:x.model_count,reported_challengers:x.challenger_only}));
const d={season:2026,week:1,home:'ATL',away:'CAR',model_margin:3,market_margin:3,actual_margin:7,eligible:false,
feature_snapshot:{predictive_distribution:{home_cover_probability:0.45,away_cover_probability:0.45,push_probability:0.10}}};
out.conditional_brier={observed:family.scoreOver(new Map([[family.gameKey(d),d]]),[family.gameKey(d)]).cover_brier,
expected_when_excluding_pushes:(0.45/(1-0.10)-1)**2};
const protocol=await import(`${root}/server/services/nfl-t60-protocol.js`);
out.capacity_late_release=protocol.sequentialCapacity([
{cutoff_at:'2026-09-10T12:00:00Z',candidates:[{id:'A',edge_points:4}]},
{cutoff_at:'2026-09-10T12:05:00Z',candidates:[{id:'B',edge_points:3}]}],
{weeklySlots:1,outcomes:{A:'released'}}).decisions;
out.capacity_late_release_note='API cannot express that A is not released until 12:10; B is incorrectly selected if final outcomes are replayed.';
const K='2026-09-13T17:00:00.000Z';
run(`INSERT INTO nfl_teams(id,abbr,name,conference,division) VALUES(1,'CHI','Chicago Bears','NFC','North'),(2,'CAR','Carolina Panthers','NFC','South')`);
run(`INSERT INTO game_lines(season,week,team,opponent,home,spread,total,gameday,gametime) VALUES(2026,2,'CAR','CHI',1,-2.5,44,'2026-09-13','13:00')`);
let seq=0;
function quote({home='Carolina Panthers',away='Chicago Bears',event='gameA',at='2026-09-13T16:50:00.000Z',requested=at,created=at,price=-120,line=-2.5,period='full_game'}){
 const id='b'+(++seq);
 run(`INSERT INTO nfl_quote_batches(batch_id,provider,requested_at,snapshot_at,mode,markets,source_ref,events,quotes,raw_hash,tape_version,created_at)
 VALUES(?,'fixture',?,?,'current','spreads','fixture',1,1,?,'v1',?)`,id,requested,at,id,created);
 run(`INSERT INTO nfl_quote_tape(quote_id,batch_id,provider,provider_event_id,commence_time,home_team,away_team,market,period,side_key,side_name,line,american_price,implied_probability,bookmaker_key,snapshot_at,raw_json,tape_version,created_at)
 VALUES(?,?,'fixture',?,?,?,?,'spreads',?,'home','home',?,?,0.5,'fixture',?,'{}','v1',?)`,id,id,event,K,home,away,period,line,price,at,created);
}
const clv=await import(`${root}/server/services/nfl-execution-clv.js`);
const life=await import(`${root}/server/services/nfl-execution-lifecycle.js`);
const {contractKey}=await import(`${root}/server/services/nfl-contract-key.js`);
const contract=contractKey({homeTeam:'Carolina Panthers',awayTeam:'Chicago Bears',commenceTime:K,market:'spreads',side:'home',line:-2.5});
const o=life.openOpportunity({contract,decisionSource:'fixture',occurredAt:'2026-09-13T12:00:00Z',book:'fixture',line:-2.5,price:-110});
life.recordObserved(o.id,{occurredAt:'2026-09-13T12:00:05Z',book:'fixture',line:-2.5,price:-110});
life.recordDecision(o.id,{occurredAt:'2026-09-13T12:01:00Z',book:'fixture',line:-2.5,price:-110});
life.recordAcceptance(o.id,{occurredAt:'2026-09-13T12:02:00Z',book:'fixture',line:-2.5,price:-110,stakeUnits:1});
quote({});
out.price_clv=clv.executionClvReport().positions[0];
quote({home:'Atlanta Falcons',away:'Baltimore Ravens',event:'gameB',at:'2026-09-13T16:59:00.000Z',price:-200,period:'first_half'});
out.foreign_event_and_period_close=clv.closingQuoteForContract({market:'spreads',side:'home',line:-2.5,kickoff:K});
const packet=await import(`${root}/server/services/review-nfl-t60-packet-v2.js`);
quote({home:'Atlanta Falcons',away:'Baltimore Ravens',event:'gameB',at:'2026-09-13T15:59:55.000Z',requested:'2026-09-13T15:59:55.000Z',created:'2026-09-13T16:00:30.000Z'});
out.packet_foreign_late_quote=packet.freezeT60Packet({season:2026,week:2,home:'CAR',away:'CHI',kickoff:K}).sources[0];
const policy=await import(`${root}/server/services/nfl-policy.js`);
const candidate={market:'spread',line:-3,american_price:-110,model_probability:0.54,push_probability:0,edge_points:4,disagreement:1,calibration_eligible:true};
out.policy_haircut={negative:policy.applyNflPolicy([candidate],{...policy.NFL_PRODUCTION_POLICY,probabilityHaircut:-0.1}).selected.length,
ordinary:policy.applyNflPolicy([candidate]).selected.length,policy_version:policy.NFL_PRODUCTION_POLICY.version};
console.log(JSON.stringify(out,null,2));
fs.writeFileSync('/Users/nick_matta/Documents/Codex/2026-09-09/so-based-on-whats-in-this/work/final-review-dirty-repros.json',JSON.stringify(out,null,2));
db.close();fs.rmSync(temp,{recursive:true,force:true});
