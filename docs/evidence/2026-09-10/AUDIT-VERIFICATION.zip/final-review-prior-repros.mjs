import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const root = '/Users/nick_matta/Documents/Codex/2026-09-09/so-based-on-whats-in-this/work/claude-final-review-20260910';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'claude-review-'));
process.env.GRIDIRON_DB_PATH=path.join(temp,'repro.sqlite');process.env.SCHEDULER_DISABLED='1';
const {db,migrate,run,rows}=await import(`${root}/server/db/index.js`);
const result={};
// Apply through 026 exactly as the migration runner does, then insert a real parent/child ledger.
for(const file of fs.readdirSync(`${root}/server/migrations`).filter(f=>/^\d+_.+\.js$/.test(f)&&f<'027').sort()){
 const mod=await import(`${root}/server/migrations/${file}`);migrate(mod.name??file.replace(/\.js$/,''),()=>mod.up(db));
}
run(`INSERT INTO nfl_execution_opportunities(id,contract_key,market,side,decision_source) VALUES ('upgrade-fixture','fixture','spreads','home','fixture')`);
run(`INSERT INTO nfl_execution_lifecycle_events(opportunity_id,state,occurred_at,source) VALUES ('upgrade-fixture','offered','2026-09-10T00:00:00Z','quote_tape')`);
const m27=await import(`${root}/server/migrations/027_decision_tape.js`);
try{migrate(m27.name,()=>m27.up(db));result.populated_upgrade='unexpected success';}catch(e){result.populated_upgrade={error:e.message,opportunities:rows('SELECT * FROM nfl_execution_opportunities').length,events:rows('SELECT * FROM nfl_execution_lifecycle_events').length};}
// Remove only our fixture before checking the fresh-install tape path.
db.exec('DROP TRIGGER IF EXISTS nfl_execution_lifecycle_events_no_delete; DELETE FROM nfl_execution_lifecycle_events; DELETE FROM nfl_execution_opportunities');
migrate(m27.name,()=>m27.up(db));
const tape=await import(`${root}/server/services/nfl-decision-tape.js`);
const d={matchup:'BAL at KC',market:'spread',selection:'KC',line:-3,american_price:-110,book:'fixture',edge_points:2,eligible:false,abstention_reason:'calibration_not_proven',feature_snapshot:{forecast_identity:{id:'model-A'},raw_forecast:{projected_margin:5}}};
const b={policy:{id:'p',version:'v1'},engine_mode:'champion',decisions:[d],selected:[]};
const first=tape.recordDecisionRun(2026,1,b,{codeHash:'code-A',dataHash:'data-A'});
const changed=tape.recordDecisionRun(2026,1,{...b,decisions:[{...d,edge_points:9,quote_id:'new-quote',feature_snapshot:{forecast_identity:{id:'model-B'},raw_forecast:{projected_margin:12}}}]},{codeHash:'code-B',dataHash:'data-B'});
result.tape_collision={first:first.run_id,second:changed.run_id,created:changed.created,stored:tape.decisionRunEvents(first.run_id)[0]};
const badBoard={...b,decisions:[{...d,matchup:'partial-first'}, {...d,matchup:null}]};
let partialError;try{tape.recordDecisionRun(2026,2,badBoard)}catch(e){partialError=e.message;}
const retry=tape.recordDecisionRun(2026,2,badBoard);
result.partial_run={error:partialError,retry,actual_events:tape.decisionRunEvents(retry.run_id).length};
const empty=tape.recordDecisionRun(2026,3,{...b,decisions:[]});run('DELETE FROM nfl_decision_runs WHERE id=?',empty.run_id);
result.empty_run_deletable=!tape.decisionRun(empty.run_id);
let i=0;for(const [margin,n]of [[0,10],[3,30],[7,20],[10,40]])for(let j=0;j<n;j++)run(`INSERT INTO game_lines(season,week,team,opponent,home,spread,total,team_score,opp_score) VALUES(2024,?,?,?,1,-3,44,?,20)`,++i,`H${i}`,`A${i}`,20+margin);
const edge=await import(`${root}/server/services/nfl-execution-edge.js`);
result.invalid_probabilities=edge.coverProbabilities(3,-10.5);
const prices=[-105,-110,-115,-120,-130,-140,-150,100,110,120];
outer:for(const a of [2.5,3,3.5,4])for(const b of [2.5,3,3.5,4])for(const pa of prices)for(const pb of prices){
 const board=edge.bestExecution([{book:'a',line:a,american_price:pa},{book:'b',line:b,american_price:pb}]);
 const ev=q=>q.win_probability*(q.american_price>0?q.american_price/100:100/-q.american_price)-q.loss_probability;
 if(ev(board.all[1])>ev(board.best)+0.005){result.ranking_reversal=board.all.map(q=>({book:q.book,line:q.line,price:q.american_price,ranking:q.total_edge,ev:ev(q)}));break outer;}
}
console.log(JSON.stringify(result,null,2));
fs.writeFileSync('/Users/nick_matta/Documents/Codex/2026-09-09/so-based-on-whats-in-this/work/final-review-prior-repros.json',JSON.stringify(result,null,2));
db.close();fs.rmSync(temp,{recursive:true,force:true});
